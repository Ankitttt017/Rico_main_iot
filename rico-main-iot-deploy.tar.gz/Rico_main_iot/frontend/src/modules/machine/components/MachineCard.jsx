import React from "react";
import { Power, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

const safeText = (value, fallback) => String(value || "").trim() || fallback;

const MachineSVG = () => (
  <svg viewBox="0 0 200 140" className="w-full h-full" fill="none">
    <rect x="20" y="100" width="160" height="20" rx="3" fill="#2d3748"/>
    <rect x="35" y="45" width="130" height="58" rx="4" fill="#4a5568"/>
    <rect x="45" y="52" width="55" height="45" rx="3" fill="#2d3748"/>
    <rect x="110" y="55" width="45" height="38" rx="3" fill="#1a202c"/>
    <rect x="114" y="59" width="37" height="20" rx="2" fill="#2b6cb0"/>
    <rect x="116" y="61" width="33" height="16" rx="1" fill="#3182ce" opacity="0.7"/>
    <circle cx="120" cy="85" r="3" fill="#68d391"/>
    <circle cx="130" cy="85" r="3" fill="#fc8181"/>
    <circle cx="140" cy="85" r="3" fill="#f6e05e"/>
    <rect x="55" y="20" width="12" height="35" rx="2" fill="#718096"/>
    <rect x="52" y="15" width="18" height="10" rx="2" fill="#4a5568"/>
    <rect x="90" y="58" width="20" height="8" rx="1" fill="#e2e8f0"/>
    <rect x="107" y="60" width="8" height="4" rx="1" fill="#cbd5e0"/>
    <rect x="36" y="65" width="8" height="25" rx="1" fill="#2d3748"/>
    <rect x="156" y="65" width="8" height="25" rx="1" fill="#2d3748"/>
    <rect x="35" y="43" width="130" height="5" rx="2" fill="#f6ad55" opacity="0.8"/>
    <rect x="45" y="118" width="15" height="8" rx="1" fill="#1a202c"/>
    <rect x="140" y="118" width="15" height="8" rx="1" fill="#1a202c"/>
  </svg>
);

const getStatusBar   = (s, active = true) => !active ? "bg-slate-300" : s === "RUNNING" ? "bg-green-500" : "bg-red-400";
const getStatusBadge = (s, active = true) => !active
  ? { bg: "bg-slate-100 text-slate-500", label: "Inactive" }
  : s === "RUNNING"
  ? { bg: "bg-green-100 text-green-700", label: "Active" }
  : s === "STOPPED"
  ? { bg: "bg-red-100 text-red-700",     label: "Stopped" }
  : { bg: "bg-orange-100 text-orange-700", label: "Management Loss" };

const MachineCard = ({ machine, division, line, plcConfig, onEdit, onToggle, onDelete }) => {
  const navigate = useNavigate();
  const status = safeText(machine?.status, "IDLE").toUpperCase();
  const isActive = machine?.is_active !== false;
  const badge  = getStatusBadge(status, isActive);
  const registerCount = Array.isArray(plcConfig?.register_config) ? plcConfig.register_config.length : 0;
  const needsMasterLink = machine?._plcOnly === true && !machine?._linkedOutsideCurrentPlant;
  const outsideCurrentPlant = machine?._linkedOutsideCurrentPlant === true;

  return (
    <article
      onClick={() => needsMasterLink ? onEdit?.(machine) : navigate(`/machine/${machine.id}`)}
      className="group cursor-pointer overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:border-teal-300 hover:shadow-lg hover:shadow-slate-200/80"
    >
      <div className="flex h-28 items-center justify-center bg-[linear-gradient(145deg,_#f8fafc_0%,_#eaf2f1_100%)] px-3 pt-3">
        <MachineSVG />
      </div>
      <div className={`h-1.5 w-full ${getStatusBar(status, isActive)}`} />
      <div className="p-2.5">
        <h3 className="line-clamp-2 min-h-[2rem] text-xs font-extrabold leading-snug text-slate-950">
          {safeText(machine?.name, "Unknown Machine")}
        </h3>
        <p className="text-[10px] text-gray-500 mt-1 font-medium">{division || safeText(machine?.category, "Uncategorized")}</p>
        <p className="text-[10px] text-gray-400 mt-0.5">{line || "—"}</p>
        <div className="mt-2 grid grid-cols-2 gap-1.5 text-[9px] font-bold">
          <span className="truncate rounded-md bg-blue-50 px-1.5 py-1 text-blue-700" title={plcConfig?.ip_address || "No PLC config"}>
            PLC: {plcConfig?.ip_address || "Not set"}
          </span>
          <span className="truncate rounded-md bg-slate-100 px-1.5 py-1 text-slate-600" title={`${registerCount} data registers`}>
            Tags: {registerCount}
          </span>
        </div>
        <div className="mt-3 flex items-center justify-between gap-2">
          <span className={`text-[9px] font-semibold px-2 py-0.5 rounded-full ${needsMasterLink || outsideCurrentPlant ? "bg-amber-100 text-amber-700" : badge.bg}`}>
            {needsMasterLink ? "Needs line link" : outsideCurrentPlant ? "PLC linked" : badge.label}
          </span>
          <div className="flex items-center gap-1">
            {!needsMasterLink && (
              <button
                type="button"
                title={isActive ? "Disable machine" : "Enable machine"}
                onClick={(event) => {
                  event.stopPropagation();
                  onToggle?.(machine);
                }}
                className={`rounded-md border px-1.5 py-1 text-[10px] font-bold ${isActive ? "border-amber-200 text-amber-700 hover:bg-amber-50" : "border-emerald-200 text-emerald-700 hover:bg-emerald-50"}`}
              >
                <Power className="h-3 w-3" />
              </button>
            )}
            <button
              type="button"
              title="Delete machine"
              onClick={(event) => {
                event.stopPropagation();
                onDelete?.(machine);
              }}
              className="rounded-md border border-red-200 px-1.5 py-1 text-[10px] font-bold text-red-700 hover:bg-red-50"
            >
              <Trash2 className="h-3 w-3" />
            </button>
            <button
              type="button"
              onClick={(event) => {
                event.stopPropagation();
                onEdit?.(machine);
              }}
              className="rounded-md border border-slate-200 px-2 py-1 text-[10px] font-bold text-slate-500 hover:border-teal-300 hover:text-teal-700"
            >
              PLC / Tags
            </button>
          </div>
        </div>
      </div>
    </article>
  );
};

export default MachineCard;
